# Write-up Template

### Analyze, choose, and justify the appropriate resource option for deploying the app.

*For **both** a VM or App Service solution for the CMS app:*
- *Analyze costs, scalability, availability, and workflow*
VMs can have very low pricing, for as little as 0.61¢ per hour, but storage would need to be considered.  VMs are scalable to 80GiB for 47.5¢ per hour.  Availability is adjustable, depending of if the app is needed to be available 24/7.

App Service can be run for free for up to 60 CPU minutes per day.  And the lowest basic plan is 7.5¢ per hour.  This can scale up to 250 GB for 77.3¢ per hour.  There is an auto scaling option for the App Service, starting at the mid-range plans.  

(Additionally, if this was hosted on premises with hardware, Azure is an estimated savings of $35,850.00 over 5 years.  Source:https://azure.microsoft.com/en-us/pricing/tco/calculator/)
- *Choose the appropriate solution (VM or App Service) for deploying the app*
The costs to run this application would be less when running on an app service because we are able to run Python directly from the app service, instead of having to pay for virtual overhead costs of OS and hardware.  To run a basic app (such as this app) it would cost 7.5¢ per hour for the basic plan.  

- *Justify your choice*
One other thing to consider with the App Service, is the ease of deploying the app.  There are less person-hours needed to spin up the app, and to maintain it.  Ease of use can be priceless.

### Assess app changes that would change your decision.

*Detail how the app and any other needs would have to change for you to change your decision in the last section.* 

If the scale of the app becomes too large in needed storage, or utilized bandwidth, the VM option may be needed.  The cost vs scale comparison may fluctuate as the app becomes larger and more resource consuming.  It is important to keep the analytics running to report on cost comparison, which is a nice option in Azure.
